<?php



function expandkeys($dir) {
	
	$values = scandir($dir);
	
	
	for ($i=0;$i<=sizeof($values);$i++) {
		
		if (substr($values[$i], 0,1) != '.') {
			$valuesFinal[] = $values[$i];
		}
		
	}



	return $valuesFinal;
	
	
}

//print_r(expandkeys('increasers.keys/'));
