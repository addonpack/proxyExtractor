﻿<?PHP
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.0
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the pasts

/*$lim = rand(300,999);*/

$lim = 99999;

set_time_limit($lim);

ini_set('max_execution_time', $lim);

ini_set('default_socket_timeout', 3);

//ini_set('memory_limit','50M');

ini_set('display_errors', 0);




function cleanRep($filename) {
	
		if($abre = @fopen($filename, "r")) {
			$source = @fread($abre, @filesize($filename));
			@fclose($abre);
			
			$lineas = explode("\n",$source);
			$linea = array();
			$arrayn = array();
			
			for ($i = 0; $i <= sizeof($lineas); $i++) {
				
				if (!$arrayn[$lineas[$i]]) {
					$final .= $lineas[$i]."\n";
					$arrayn[$lineas[$i]] = true;
				}
			}
		
			$abre = @fopen($filename, "w");
			@fwrite($abre, $final);
			@fclose($abre);
		}
}


cleanRep('increasers.txt');


?>
CLEANED
	