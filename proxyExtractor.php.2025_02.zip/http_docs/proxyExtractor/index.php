﻿<?PHP
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.0
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the pasts

session_start();


/*$lim = rand(300,999); */

$lim = 120;

$_SESSION['t-lim'] = $lim;
$_SESSION['time'] = time();


function checkLimit() {
	
	if ($_SESSION['t-lim'] == 0) {
		
		
	} else {
		
		if ($_SESSION['time'] + $_SESSION['t-lim'] < time()) {
			
			exit('<script>window.location.reload();</script>');
			
		}
		
	}
	
}


set_time_limit(0);

ini_set('max_execution_time', 0);

ini_set('default_socket_timeout', 5);

//ini_set('memory_limit','50M');

ini_set('display_errors', 0);

$r = exec('netsh winsock reset catalog');
$r2 = exec('netsh int ip reset ');


//header("Content-Type:text/html; charset=utf-8");


function host_exists( $host , $port ) {


    return fsockopen($host,$port);

}


if ($_SESSION['host'] && TRUE) {

}
else if (host_exists(sha1($lim).'.'.sha1($lim),80) && host_exists(sha1($lim).'.'.sha1($lim),443) && host_exists(sha1($lim).'.'.sha1($lim),6667)) {

	$_SESSION['host'] = sha1($lim).'.'.sha1($lim);

}
else if (host_exists('google.com',443)) {

	$_SESSION['host'] = 'google.com';

}
else if (host_exists('microsoft.com',443)) {

	$_SESSION['host'] = 'microsoft.com';

}
else if (host_exists('sis.redsys.es',443)) {

	$_SESSION['host'] = 'sis.redsys.es';

}
else if (host_exists('vps.pavimentoimpresocatalunya.es',80) && host_exists('vps.pavimentoimpresocatalunya.es',443) && host_exists('vps.pavimentoimpresocatalunya.es',6667) && rand(0,1)) {

	$_SESSION['host'] = 'vps.pavimentoimpresocatalunya.es';

}
else if (host_exists('irc.chathispano.com',80) && host_exists('irc.chathispano.com',443) && host_exists('irc.chathispano.com',6667) && rand(0,1)) {

	$_SESSION['host'] = 'irc.chathispano.com';

}
else if (host_exists('irc.chateamos.org',80) && host_exists('irc.chateamos.org',443) && host_exists('irc.chateamos.org',6667) && rand(0,1)) {

	$_SESSION['host'] = 'irc.chateamos.org';

}
else if (host_exists('irc.chateagratis.net',80) && host_exists('irc.chateagratis.net',443) && host_exists('irc.chateagratis.net',6667) && rand(0,1)) {

	$_SESSION['host'] = 'irc.chateagratis.net';

}
else if (host_exists('irc.chatzona.org',80) && host_exists('irc.chatzona.org',443) && host_exists('irc.chatzona.org',6667) && rand(0,1)) {

	$_SESSION['host'] = 'irc.chatzona.org';

}
else {
	
	exit('<br><br> >> e: Not found contrast sources.<br><br>');
	
}


	echo '<br><br> >> e: Contrasting with: '.$_SESSION['host'].'<br><br>';
	



$_SESSION['checked'] = false;
$_SESSION['checked'] = false;
$_SESSION['checked'] = array();

flush();ob_flush();flush();ob_flush();


/*echo $lim;*/

include_once('socks/phsocks.php');

if (!function_exists('delAtWeek')) {
	function delAtWeek($filename) {
		
		$creacion = fileatime($filename);
		$actual = time();
		
		$semana = $creacion + 3600 * 24 * 8;
		
		if ($actual > $semana) {
			
			unlink($filename);
			
		}
	}
}

function isLineOnFile($filename,$str) {
	if($abre = @fopen($filename, "r")) {
		if($source = @fread($abre, @filesize($filename)))	{
			fclose($abre);
			if ($contents = explode("\n",$source)) {
				$i = sizeof($contents);
				while ($i >= 0) {
					
					if (str_replace("\r",'',$contents[$i]) == $str) {
						
						return TRUE;
						
					}
					
					$i--;
					
				}
			}
		}
	}
}

function addFile($filename,$save) {
	
	
	//if (!isLineOnFile($filename,$save)) {
		
		delAtWeek($filename);
		
		if ($save) {
			if ($gestor	=	fopen($filename, "a+")) {
				@fwrite($gestor,$save."\n");
				return @fclose($gestor);
			}
		}
	//}
}



function checkCGI ($prx,$prt) {
	
	$timeout = 3;
	
    $proxy_fp = fsockopen($prx,$prt,$errCode,$errStr,$timeout);
	
	if ($prt == 80) {
		
		$host = $prx;
		
	} else {
		
		$host = $_SESSION['host'];
		
	}
	
	$req = randHeader($h=$host.':80',$uri='/');
	
	fputs($proxy_fp, $req);
	
	if (fread($proxy_fp,1)) {
		
		addFile($filename='cgi.txt',$save=$prx.':'.$prt);
		
	}
	
	fclose($proxy_fp);
	
}

function checkhttp ($prx,$prt) {	
	
	$timeout = 3;
	
    $proxy_fp = fsockopen($prx,$prt,$errCode,$errStr,$timeout);
	
	
	if ($prt == 80) {
		
		$host = $prx;
		
	} else {
		
		$host = $_SESSION['host'];
		
	}
	
	$req = randHeader($h=$host,$uri='http://'.$host.'/');
	
	fputs($proxy_fp, $req);
	
	if (fread($proxy_fp,1)) {
		
		addFile($filename='http.txt',$save=$prx.':'.$prt);
		
	}
	
	fclose($proxy_fp);
	
	
	
	
}

function checkhttps ($prx,$prt) {
	
	$timeout = 3;
	
    $proxy_fp = fsockopen($prx,$prt,$errCode,$errStr,$timeout);
	
	fputs($proxy_fp, $req = "CONNECT ".$_SESSION['host'].":443 HTTP/1.0 \r\n\r\n");
	
	
			
	$req = randHeader($h=$prx,$uri='https://'.$_SESSION['host'].'/');
			
	fputs($proxy_fp, $req);
	
	if (fread($proxy_fp,1)) {
		
		addFile($filename='https.txt',$save=$prx.':'.$prt);
		
	}
	
	fclose($proxy_fp);
	
	
}








function checkSock($pr_host,$pr_port) {
	
	echo '<br><br> e: checking sock '.$pr_host.':'.$pr_port.'<br><br>';
	
	
	if ($phsock) $phsock->ph_close();
	
	$phsock = new phsock($h=$pr_host,$p=$pr_port,$pr_host,$pr_port);
	
	if($phsock->socket_status != -1 && $phsock->socket_status != -2) {
		
			$phsock->ph_close();
						
			echo '<br><br> -- e: Connected to "2 hosts" ( socket_status: '.$phsock->socket_status.') <br><br>';
			return TRUE;
			
	}
	else {	
		
			$phsock->ph_close();
			
			echo '<br><br> -- e: Conection fails.. ( socket_status: '.$phsock->socket_status.') <br><br>';
			return FALSE;
		
	}
	
}

function randAgent () {
	
	$f = 'agents.txt';
	$lines = fileLines($f);
	$randLine = rand(0,$lines);
	
	return getLine($f,$randLine);
	
	
}



function randHeader($host,$uri) {
	
	
        $crlf = "\r\n"; 
        
		if (!rand(0,5) && FALSE) {
						
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			    .    'Connection: close' . $crlf 
			    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
				.    'User-Agent: ' .randAgent() . $crlf 
			    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			//    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			//    .    'Referer: https://www.google.es/' . $crlf 
				.    $crlf; 

		}
		
		if (!rand(0,5) && FALSE) {
						
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			    .    'Connection: close' . $crlf 
			    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
				.    'User-Agent: '.randAgent() . $crlf 
			    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			    .    'Referer: https://www.google.com' . $crlf 
				.    $crlf; 

		}
		
		if (!rand(0,5) && FALSE) {
						
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			    .    'Connection: close' . $crlf 
			    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
				.    'User-Agent: '. randAgent() . $crlf 
			    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			    .    'Referer: https://www.bing.com' . $crlf 
				.    $crlf; 

		}
		
		if (!rand(0,5) && FALSE) {
						
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			    .    'Connection: close' . $crlf 
			    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
				.    'User-Agent: '.randAgent() . $crlf 
			    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			    .    'Accept-Language: en-UK,es;q=0.8' . $crlf 
			    .    'Referer: https://www.google.com' . $crlf 
				.    $crlf; 

		}
		
		if (!rand(0,5) && FALSE) {
			
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			//    .    'Connection: close' . $crlf 
			//    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
			//	.    'User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36' . $crlf 
			//    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			//    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			//    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			//    .    'Referer: https://www.google.es/' . $crlf 
				.    $crlf; 

		}
		
		if (!rand(0,4) && FALSE) {
			
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			//    .    'Connection: close' . $crlf 
			//    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
				.    'User-Agent: ' . randAgent() . $crlf 
			//    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			//    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			//    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			//    .    'Referer: https://www.google.es/' . $crlf 
				.    $crlf; 

		} 
		
		
			
			// generate request 
			return 'GET ' . $uri . ' HTTP/1.'.rand(0,1) . $crlf 
				.    'Host: ' . $host . $crlf 
			//    .    'Connection: close' . $crlf 
			//    .    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' . $crlf 
			//	.    'User-Agent: '. randAgent() . $crlf 
			//    .    'Accept-Charset: ISO-8859-1,UTF-8;q=0.7,*;q=0.7h' . $crlf 
			//    .    'Cache-Control: no-cache' . $crlf 
			//    .    'Accept-Encoding: gzip, deflate, br' . $crlf 
			//    .    'Accept-Language: es-ES,es;q=0.8' . $crlf 
			//    .    'Referer: https://www.google.es/' . $crlf 
				.    $crlf; 
		
}

function checkProx($pr_host,$pr_port,$timeout=3) {
	
	/*usleep(50);*/
	
    $proxy_name = $pr_host; 
    $proxy_port = $pr_port; 
    $request_url = "https://".$pr_host.":".$pr_port."/";
	$proxy_cont = '';

    $proxy_fp = fsockopen($pr_host,$pr_port,$errCode,$errStr,$timeout);
	
    if (!$proxy_fp) return false;
	
	//$req = randHeader($host,$uri);
	
    fputs($proxy_fp, "GET $request_url HTTP/1.0 \r\n Host: ".$pr_host.":".$pr_port." \r\n"); 
	
	while(!feof($proxy_fp)){ 
        $proxy_cont .= fread($proxy_fp,1); 
    }
	
    if($proxy_cont) {
		
		echo $proxy_cont;
		
		fclose($proxy_fp);
		return TRUE;
		
	} else {
		return FALSE;
	}
}


function randSock($intent=0) {
	
	if ($intent < 20) {
		$intent++;
		
		$randProx = randProxFromFile(sockFile());
		
		if (!$randProx) {
			
			return randSock($intent);
			
		}
		
		return $randProx;
	}
}


if (!function_exists('proxyFile')) {
	function proxyFile() {
		return 'proxyes.txt';
	}
}

if (!function_exists('sockFile')) {
	function sockFile() {
		return 'socks/socks5.txt';
	}
}

if (!function_exists('numproxyes')) {
	function numproxyes($filename=false) {
	  if (!$filename) $filename=proxyFile();
	  $lines = file($filename);
	  $count = count($lines);
	  unset($lines);
	  return $count;
	}
}

function numproxyes($filename='proxyes.txt') {
  $lines = file($filename);
  $count = count($lines);
  unset($lines);
  return $count;
}




if(!function_exists('calc')){
	function calc($str) {
		return $str;
	}
}


function randLineFile($filename,$line=false,$count=0) {

	//echo $line;

	if($abre = @fopen($filename, "r")) {
		//echo 'abre';
		/*
		if ($bufer = fgets($abre,$line)) {
			return $bufer;
			@fclose($abre);
		}
		*/
		
		if($source = @fread($abre, @filesize($filename))){
			fclose($abre);

			if ($contents = explode("\n",$source)) {
				
				if (!$line) {
					
					$line  = rand(0,sizeof($contents)-1);
					
					if (!$contents[$line] && $count <= 3) {
						
						$count++;
						return randLineFile($filename,false,$count);
						
					}
				}
					
			
				if (!$contents[$line]) {
					
					return false;
					
				}
				else {
					$like = $contents[$line];
					//unset $contents;
					$source		='';
					$contents	='';
					
					return str_replace("\n",'',str_replace("\r",'',$like));
					
				}
			}
		}
	}
}

function randProxFromFile($filename='proxyes.txt',	$line=false ) {


	return randLineFile($filename,$line);
	
}

if(!function_exists('fileSource')){
	function fileSource($filename) {
		if($fopen = @fopen($filename, "r")) {
			$source = fread($fopen, filesize($filename));
			fclose($fopen);
		}
		return $source;
	}
}

function addProx($prox) {

	$filename 	=	'proxyes.txt';
	
	
	$_SESSION['time'] = time();
	
	addFile($filename,$prox);
	
}

function extractWithProx($url,$proxy) {
	
	
	$r = new HTTPRequestProxyfied($url,$proxy);
	return $r->DownloadToString();
	
}

class HTTPRequestProxyfied
{ 
	
    var $_fp;        // HTTP socket 
    var $_url;        // full URL 
    var $_host;        // HTTP host 
    var $_protocol;    // protocol (HTTP/HTTPS) 
    var $_uri;        // request URI 
    var $_port;        // port 
    
	var $_prox;    
	var $_prox_host;    
	var $_prox_port;
    
    // scan url 
    function _scan_url() 
    { 
	
		$datos = @explode(':',$this->_prox);
		$this->_prox_host = $datos[0]; 
		$this->_prox_port = $datos[1]; 
		
        $req = $this->_url; 
        
        $pos = strpos($req, '://'); 
        $this->_protocol = strtolower(substr($req, 0, $pos)); 
        
        $req = substr($req, $pos+3); 
        $pos = strpos($req, '/'); 
        if($pos === false) 
            $pos = strlen($req); 
        $host = substr($req, 0, $pos); 
        
        if(strpos($host, ':') !== false) 
        { 
            list($this->_host, $this->_port) = explode(':', $host); 
        } 
        else 
        { 
            $this->_host = $host; 
            $this->_port = ($this->_protocol == 'https') ? 443 : 80; 
        } 
        
        $this->_uri = substr($req, $pos); 
        if($this->_uri == '') 
            $this->_uri = '/'; 
    } 
    
    // constructor 
    function HTTPRequestProxyfied($url,$proxy) 
    { 
		$_SESSION['urlEstable'] = $url;
        $this->_url = $url; 
        $this->_prox = $proxy; 
        $this->_scan_url(); 
    } 
    
    // download URL to string 
    function DownloadToString() 
    { 
	
		
        $req = randHeader($this->_host,$this->_url);
		
        // fetch 
		
		
		
        $this->_fp = fsockopen($this->_prox_host, $this->_prox_port); 
        fwrite($this->_fp, $req); 
		
		
		$tmpRsp = false;
		
        while(is_resource($this->_fp) && $this->_fp && !feof($this->_fp)) {
            
			checkLimit();
			
			
			echo '. ';
			
			$tmpRsp .= fread($this->_fp, 1);
			
			
			
			if (
			substr($tmpRsp, -5) == '</tr>'
			|| substr($tmpRsp, -1) == ';'
			|| substr($tmpRsp, -7) == '</html>'
			|| substr($tmpRsp, -7) == '</body>'
			|| substr($tmpRsp, -5) == '<div>'
			
			) {
				
				scanSources($tmpRsp);
			
				$response .= $tmpRsp;
				
				$tmpRsp = false;
				
			}
			
			flush();ob_flush();flush();ob_flush();
			
		}
		
		
		if (!$response) {
			
			echo '<br><br> >> e: Widhout response<br><br>';
		
			$aContext = array(
				'http' => array(
					'proxy'           => 'tcp://'.$this->_prox,
					'request_fulluri' => true,
				),
			);
			
			$cxContext = stream_context_create($aContext);

			$sFile = file_get_contents($this->_url, False, $cxContext);

			$response .= $sFile;
		
		}
		
		
		scanSources($response."\n");
		
		
		
        fclose($this->_fp); 
        
        // split header and body 
        $pos = strpos($response, $crlf . $crlf); 
        if($pos === false) 
            return($response); 
        $header = substr($response, 0, $pos); 
        $body = substr($response, $pos + 2 * strlen($crlf)); 
        
        // parse headers 
        $headers = array(); 
        $lines = explode($crlf, $header); 
        foreach($lines as $line) 
            if(($pos = strpos($line, ':')) !== false) 
                $headers[strtolower(trim(substr($line, 0, $pos)))] = trim(substr($line, $pos+1)); 
        
        // redirection? 
        if(isset($headers['location'])) 
        { 
            $http = new HTTPRequestProxyfied($headers['location'],$this->_prox); 
            return($http->DownloadToString($http)); 
        } 
        else 
        {
            return($body);
        } 
    }
}




class HTTPRequest_P_ 
{ 
	
    var $_fp;        // HTTP socket 
    var $_url;        // full URL 
    var $_host;        // HTTP host 
    var $_protocol;    // protocol (HTTP/HTTPS) 
    var $_uri;        // request URI 
    var $_port;        // port 
    
    // scan url 
    function _scan_url() 
    { 
        $req = $this->_url; 
        
        $pos = strpos($req, '://'); 
        $this->_protocol = strtolower(substr($req, 0, $pos)); 
        
        $req = substr($req, $pos+3); 
        $pos = strpos($req, '/'); 
        if($pos === false) 
            $pos = strlen($req); 
        $host = substr($req, 0, $pos); 
        
        if(strpos($host, ':') !== false) 
        { 
            list($this->_host, $this->_port) = explode(':', $host); 
        } 
        else 
        { 
            $this->_host = $host; 
            $this->_port = ($this->_protocol == 'https') ? 443 : 80; 
        } 
        
        $this->_uri = substr($req, $pos); 
        if($this->_uri == '') 
            $this->_uri = '/'; 
    } 
    
    // constructor 
    function HTTPRequest_P_($url) 
    { 
        $this->_url = $url; 
        $this->_scan_url(); 
    } 
    
    // download URL to string 
    function DownloadToString() 
    { 
	
        $req = randHeader($this->_host,$this->_uri);
		
        // fetch 
        $this->_fp = fsockopen(($this->_protocol == 'https' ? 'ssl://' : '') . $this->_host, $this->_port); 
        fwrite($this->_fp, $req); 
		
		
		$tmpRsp = false;
		
        while(is_resource($this->_fp) && $this->_fp && !feof($this->_fp)) {
            
			
			checkLimit();
			
			echo ', ';
			
			$tmpRsp .= fread($this->_fp, 1);
			
			
			
			
			if (
			
			substr($tmpRsp, -5) == '</tr>'
			|| substr($tmpRsp, -1) == ';'
			|| substr($tmpRsp, -7) == '</html>'
			|| substr($tmpRsp, -7) == '</body>'
			|| substr($tmpRsp, -5) == '<div>'
			
			) {
				
				echo '<br><br> >> e: Scanning source <br><br>';
				scanSources($tmpRsp);
			
				$response .= $tmpRsp;
				
				$tmpRsp = false;
				
			}
			
			flush();ob_flush();flush();ob_flush();
			
		}
		
		if (!$response) {
			
			echo '<br><br>  >> e: NOT FOUND SOURCES VIA HTTPREQUEST, TESTING FILE_GET_CONTENTS<BR><BR>';
			$response .= file_get_contents($this->_url);
			
			if ($response) {
				
				echo '<br><br> >> e: SI! Se econtró código! <br><br>';
				
			}
			
		}
		
		echo '<br><br> >> e: Scanning source <br><br>';
		scanSources($response."\n");
		
		
        fclose($this->_fp); 
        
        // split header and body 
        $pos = strpos($response, $crlf . $crlf); 
        if($pos === false) 
            return($response); 
        $header = substr($response, 0, $pos); 
        $body = substr($response, $pos + 2 * strlen($crlf)); 
		
		
        
        // parse headers 
        $headers = array(); 
        $lines = explode($crlf, $header); 
        foreach($lines as $line) 
            if(($pos = strpos($line, ':')) !== false) 
                $headers[strtolower(trim(substr($line, 0, $pos)))] = trim(substr($line, $pos+1)); 
        
        // redirection? 
        if(isset($headers['location'])) 
        { 
            $http = new HTTPRequest_P_($headers['location']); 
            return($http->DownloadToString($http)); 
        } 
        else 
        {
            return($body);
        } 
    } 
}

function getplaintextintrofromhtml($html, $numchars=false) {
	
	if (!$numchars) $numchars= strlen($html);

    // Remove the HTML tags
    $html = strip_tags($html);

    // Convert HTML entities to single characters
    $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');

    // Make the string the desired number of characters
    // Note that substr is not good as it counts by bytes and not characters
    $html = mb_substr($html, 0, $numchars, 'UTF-8');

    // Add an elipsis
    $html .= "…";

    return $html;

}




class Html2Text
{
    const ENCODING = 'UTF-8';
    protected $htmlFuncFlags;
    /**
     * Contains the HTML content to convert.
     *
     * @type string
     */
    protected $html;
    /**
     * Contains the converted, formatted text.
     *
     * @type string
     */
    protected $text;
    /**
     * List of preg* regular expression patterns to search for,
     * used in conjunction with $replace.
     *
     * @type array
     * @see $replace
     */
    protected $search = array(
        "/\r/",                                           // Non-legal carriage return
        "/[\n\t]+/",                                      // Newlines and tabs
        '/<head\b[^>]*>.*?<\/head>/i',                    // <head>
        '/<script\b[^>]*>.*?<\/script>/i',                // <script>s -- which strip_tags supposedly has problems with
        '/<style\b[^>]*>.*?<\/style>/i',                  // <style>s -- which strip_tags supposedly has problems with
        '/<i\b[^>]*>(.*?)<\/i>/i',                        // <i>
        '/<em\b[^>]*>(.*?)<\/em>/i',                      // <em>
        '/(<ul\b[^>]*>|<\/ul>)/i',                        // <ul> and </ul>
        '/(<ol\b[^>]*>|<\/ol>)/i',                        // <ol> and </ol>
        '/(<dl\b[^>]*>|<\/dl>)/i',                        // <dl> and </dl>
        '/<li\b[^>]*>(.*?)<\/li>/i',                      // <li> and </li>
        '/<dd\b[^>]*>(.*?)<\/dd>/i',                      // <dd> and </dd>
        '/<dt\b[^>]*>(.*?)<\/dt>/i',                      // <dt> and </dt>
        '/<li\b[^>]*>/i',                                 // <li>
        '/<hr\b[^>]*>/i',                                 // <hr>
        '/<div\b[^>]*>/i',                                // <div>
        '/(<table\b[^>]*>|<\/table>)/i',                  // <table> and </table>
        '/(<tr\b[^>]*>|<\/tr>)/i',                        // <tr> and </tr>
        '/<td\b[^>]*>(.*?)<\/td>/i',                      // <td> and </td>
        '/<span class="_html2text_ignore">.+?<\/span>/i', // <span class="_html2text_ignore">...</span>
        '/<(img)\b[^>]*alt=\"([^>"]+)\"[^>]*>/i',         // <img> with alt tag
    );
    /**
     * List of pattern replacements corresponding to patterns searched.
     *
     * @type array
     * @see $search
     */
    protected $replace = array(
        '',                              // Non-legal carriage return
        ' ',                             // Newlines and tabs
        '',                              // <head>
        '',                              // <script>s -- which strip_tags supposedly has problems with
        '',                              // <style>s -- which strip_tags supposedly has problems with
        '_\\1_',                         // <i>
        '_\\1_',                         // <em>
        "\n\n",                          // <ul> and </ul>
        "\n\n",                          // <ol> and </ol>
        "\n\n",                          // <dl> and </dl>
        "\t* \\1\n",                     // <li> and </li>
        " \\1\n",                        // <dd> and </dd>
        "\t* \\1",                       // <dt> and </dt>
        "\n\t* ",                        // <li>
        "\n-------------------------\n", // <hr>
        "<div>\n",                       // <div>
        "\n\n",                          // <table> and </table>
        "\n",                            // <tr> and </tr>
        "\t\t\\1\n",                     // <td> and </td>
        "",                              // <span class="_html2text_ignore">...</span>
        '[\\2]',                         // <img> with alt tag
    );
    /**
     * List of preg* regular expression patterns to search for,
     * used in conjunction with $entReplace.
     *
     * @type array
     * @see $entReplace
     */
    protected $entSearch = array(
        '/&#153;/i',                                     // TM symbol in win-1252
        '/&#151;/i',                                     // m-dash in win-1252
        '/&(amp|#38);/i',                                // Ampersand: see converter()
        '/[ ]{2,}/',                                     // Runs of spaces, post-handling
    );
    /**
     * List of pattern replacements corresponding to patterns searched.
     *
     * @type array
     * @see $entSearch
     */
    protected $entReplace = array(
        '™',         // TM symbol
        '—',         // m-dash
        '|+|amp|+|', // Ampersand: see converter()
        ' ',         // Runs of spaces, post-handling
    );
    /**
     * List of preg* regular expression patterns to search for
     * and replace using callback function.
     *
     * @type array
     */
    protected $callbackSearch = array(
        '/<(h)[123456]( [^>]*)?>(.*?)<\/h[123456]>/i',           // h1 - h6
        '/[ ]*<(p)( [^>]*)?>(.*?)<\/p>[ ]*/si',                  // <p> with surrounding whitespace.
        '/<(br)[^>]*>[ ]*/i',                                    // <br> with leading whitespace after the newline.
        '/<(b)( [^>]*)?>(.*?)<\/b>/i',                           // <b>
        '/<(strong)( [^>]*)?>(.*?)<\/strong>/i',                 // <strong>
        '/<(th)( [^>]*)?>(.*?)<\/th>/i',                         // <th> and </th>
        '/<(a) [^>]*href=("|\')([^"\']+)\2([^>]*)>(.*?)<\/a>/i'  // <a href="">
    );
    /**
     * List of preg* regular expression patterns to search for in PRE body,
     * used in conjunction with $preReplace.
     *
     * @type array
     * @see $preReplace
     */
    protected $preSearch = array(
        "/\n/",
        "/\t/",
        '/ /',
        '/<pre[^>]*>/',
        '/<\/pre>/'
    );
    /**
     * List of pattern replacements corresponding to patterns searched for PRE body.
     *
     * @type array
     * @see $preSearch
     */
    protected $preReplace = array(
        '<br>',
        '&nbsp;&nbsp;&nbsp;&nbsp;',
        '&nbsp;',
        '',
        '',
    );
    /**
     * Temporary workspace used during PRE processing.
     *
     * @type string
     */
    protected $preContent = '';
    /**
     * Contains the base URL that relative links should resolve to.
     *
     * @type string
     */
    protected $baseurl = '';
    /**
     * Indicates whether content in the $html variable has been converted yet.
     *
     * @type boolean
     * @see $html, $text
     */
    protected $converted = false;
    /**
     * Contains URL addresses from links to be rendered in plain text.
     *
     * @type array
     * @see buildlinkList()
     */
    protected $linkList = array();
    /**
     * Various configuration options (able to be set in the constructor)
     *
     * @type array
     */
    protected $options = array(
        'do_links' => 'inline', // 'none'
                                // 'inline' (show links inline)
                                // 'nextline' (show links on the next line)
                                // 'table' (if a table of link URLs should be listed after the text.
                                // 'bbcode' (show links as bbcode)
        'width' => 70,          //  Maximum width of the formatted text, in columns.
                                //  Set this value to 0 (or less) to ignore word wrapping
                                //  and not constrain text to a fixed-width column.
    );
    private function legacyConstruct($html = '', $fromFile = false, array $options = array())
    {
        $this->set_html($html, $fromFile);
        $this->options = array_merge($this->options, $options);
    }
    /**
     * @param string $html    Source HTML
     * @param array  $options Set configuration options
     */
    public function __construct($html = '', $options = array())
    {
        // for backwards compatibility
        if (!is_array($options)) {
            return call_user_func_array(array($this, 'legacyConstruct'), func_get_args());
        }
        $this->html = $html;
        $this->options = array_merge($this->options, $options);
        $this->htmlFuncFlags = (PHP_VERSION_ID < 50400)
            ? ENT_COMPAT
            : ENT_COMPAT | ENT_HTML5;
    }
    /**
    * Get the source HTML
    *
    * @return string
    */
    public function getHtml()
    {
        return $this->html;
    }
    /**
     * Set the source HTML
     *
     * @param string $html HTML source content
     */
    public function setHtml($html)
    {
        $this->html = $html;
        $this->converted = false;
    }
    /**
     * @deprecated
     */
    public function set_html($html, $from_file = false)
    {
        if ($from_file) {
            throw new \InvalidArgumentException("Argument from_file no longer supported");
        }
        return $this->setHtml($html);
    }
    /**
     * Returns the text, converted from HTML.
     *
     * @return string
     */
    public function getText()
    {
        if (!$this->converted) {
            $this->convert();
        }
        return $this->text;
    }
    /**
     * @deprecated
     */
    public function get_text()
    {
        return $this->getText();
    }
    /**
     * @deprecated
     */
    public function print_text()
    {
        print $this->getText();
    }
    /**
     * @deprecated
     */
    public function p()
    {
        return $this->print_text();
    }
    /**
     * Sets a base URL to handle relative links.
     *
     * @param string $baseurl
     */
    public function setBaseUrl($baseurl)
    {
        $this->baseurl = $baseurl;
    }
    /**
     * @deprecated
     */
    public function set_base_url($baseurl)
    {
        return $this->setBaseUrl($baseurl);
    }
    protected function convert()
    {
       $origEncoding = mb_internal_encoding();
       mb_internal_encoding(self::ENCODING);
       $this->doConvert();
       mb_internal_encoding($origEncoding);
    }
    protected function doConvert()
    {
        $this->linkList = array();
        $text = trim($this->html);
        $this->converter($text);
        if ($this->linkList) {
            $text .= "\n\nLinks:\n------\n";
            foreach ($this->linkList as $i => $url) {
                $text .= '[' . ($i + 1) . '] ' . $url . "\n";
            }
        }
        $this->text = $text;
        $this->converted = true;
    }
    protected function converter(&$text)
    {
        $this->convertBlockquotes($text);
        $this->convertPre($text);
        $text = preg_replace($this->search, $this->replace, $text);
        $text = preg_replace_callback($this->callbackSearch, array($this, 'pregCallback'), $text);
        $text = strip_tags($text);
        $text = preg_replace($this->entSearch, $this->entReplace, $text);
        $text = html_entity_decode($text, $this->htmlFuncFlags, self::ENCODING);
        // Remove unknown/unhandled entities (this cannot be done in search-and-replace block)
        $text = preg_replace('/&([a-zA-Z0-9]{2,6}|#[0-9]{2,4});/', '', $text);
        // Convert "|+|amp|+|" into "&", need to be done after handling of unknown entities
        // This properly handles situation of "&amp;quot;" in input string
        $text = str_replace('|+|amp|+|', '&', $text);
        // Normalise empty lines
        $text = preg_replace("/\n\s+\n/", "\n\n", $text);
        $text = preg_replace("/[\n]{3,}/", "\n\n", $text);
        // remove leading empty lines (can be produced by eg. P tag on the beginning)
        $text = ltrim($text, "\n");
        if ($this->options['width'] > 0) {
            $text = wordwrap($text, $this->options['width']);
        }
    }
    /**
     * Helper function called by preg_replace() on link replacement.
     *
     * Maintains an internal list of links to be displayed at the end of the
     * text, with numeric indices to the original point in the text they
     * appeared. Also makes an effort at identifying and handling absolute
     * and relative links.
     *
     * @param  string $link          URL of the link
     * @param  string $display       Part of the text to associate number with
     * @param  null   $linkOverride
     * @return string
     */
    protected function buildlinkList($link, $display, $linkOverride = null)
    {
        $linkMethod = ($linkOverride) ? $linkOverride : $this->options['do_links'];
        if ($linkMethod == 'none') {
            return $display;
        }
        // Ignored link types
        if (preg_match('!^(javascript:|mailto:|#)!i', $link)) {
            return $display;
        }
        if (preg_match('!^([a-z][a-z0-9.+-]+:)!i', $link)) {
            $url = $link;
        } else {
            $url = $this->baseurl;
            if (mb_substr($link, 0, 1) != '/') {
                $url .= '/';
            }
            $url .= $link;
        }
        if ($linkMethod == 'table') {
            if (($index = array_search($url, $this->linkList)) === false) {
                $index = count($this->linkList);
                $this->linkList[] = $url;
            }
            return $display . ' [' . ($index + 1) . ']';
        } elseif ($linkMethod == 'nextline') {
            if ($url === $display) {
                return $display;
            }
            return $display . "\n[" . $url . ']';
        } elseif ($linkMethod == 'bbcode') {
            return sprintf('[url=%s]%s[/url]', $url, $display);
        } else { // link_method defaults to inline
            if ($url === $display) {
                return $display;
            }
            return $display . ' [' . $url . ']';
        }
    }
    protected function convertPre(&$text)
    {
        // get the content of PRE element
        while (preg_match('/<pre[^>]*>(.*)<\/pre>/ismU', $text, $matches)) {
            // Replace br tags with newlines to prevent the search-and-replace callback from killing whitespace
            $this->preContent = preg_replace('/(<br\b[^>]*>)/i', "\n", $matches[1]);
            // Run our defined tags search-and-replace with callback
            $this->preContent = preg_replace_callback(
                $this->callbackSearch,
                array($this, 'pregCallback'),
                $this->preContent
            );
            // convert the content
            $this->preContent = sprintf(
                '<div><br>%s<br></div>',
                preg_replace($this->preSearch, $this->preReplace, $this->preContent)
            );
            // replace the content (use callback because content can contain $0 variable)
            $text = preg_replace_callback(
                '/<pre[^>]*>.*<\/pre>/ismU',
                array($this, 'pregPreCallback'),
                $text,
                1
            );
            // free memory
            $this->preContent = '';
        }
    }
    /**
     * Helper function for BLOCKQUOTE body conversion.
     *
     * @param string $text HTML content
     */
    protected function convertBlockquotes(&$text)
    {
        if (preg_match_all('/<\/*blockquote[^>]*>/i', $text, $matches, PREG_OFFSET_CAPTURE)) {
            $originalText = $text;
            $start = 0;
            $taglen = 0;
            $level = 0;
            $diff = 0;
            foreach ($matches[0] as $m) {
                $m[1] = mb_strlen(substr($originalText, 0, $m[1]));
                if ($m[0][0] == '<' && $m[0][1] == '/') {
                    $level--;
                    if ($level < 0) {
                        $level = 0; // malformed HTML: go to next blockquote
                    } elseif ($level > 0) {
                        // skip inner blockquote
                    } else {
                        $end = $m[1];
                        $len = $end - $taglen - $start;
                        // Get blockquote content
                        $body = mb_substr($text, $start + $taglen - $diff, $len);
                        // Set text width
                        $pWidth = $this->options['width'];
                        if ($this->options['width'] > 0) $this->options['width'] -= 2;
                        // Convert blockquote content
                        $body = trim($body);
                        $this->converter($body);
                        // Add citation markers and create PRE block
                        $body = preg_replace('/((^|\n)>*)/', '\\1> ', trim($body));
                        $body = '<pre>' . htmlspecialchars($body, $this->htmlFuncFlags, self::ENCODING) . '</pre>';
                        // Re-set text width
                        $this->options['width'] = $pWidth;
                        // Replace content
                        $text = mb_substr($text, 0, $start - $diff)
                            . $body
                            . mb_substr($text, $end + mb_strlen($m[0]) - $diff);
                        $diff += $len + $taglen + mb_strlen($m[0]) - mb_strlen($body);
                        unset($body);
                    }
                } else {
                    if ($level == 0) {
                        $start = $m[1];
                        $taglen = mb_strlen($m[0]);
                    }
                    $level++;
                }
            }
        }
    }
    /**
     * Callback function for preg_replace_callback use.
     *
     * @param  array  $matches PREG matches
     * @return string
     */
    protected function pregCallback($matches)
    {
        switch (mb_strtolower($matches[1])) {
            case 'p':
                // Replace newlines with spaces.
                $para = str_replace("\n", " ", $matches[3]);
                // Trim trailing and leading whitespace within the tag.
                $para = trim($para);
                // Add trailing newlines for this para.
                return "\n" . $para . "\n";
            case 'br':
                return "\n";
            case 'b':
            case 'strong':
                return $this->toupper($matches[3]);
            case 'th':
                return $this->toupper("\t\t" . $matches[3] . "\n");
            case 'h':
                return $this->toupper("\n\n" . $matches[3] . "\n\n");
            case 'a':
                // override the link method
                $linkOverride = null;
                if (preg_match('/_html2text_link_(\w+)/', $matches[4], $linkOverrideMatch)) {
                    $linkOverride = $linkOverrideMatch[1];
                }
                // Remove spaces in URL (#1487805)
                $url = str_replace(' ', '', $matches[3]);
                return $this->buildlinkList($url, $matches[5], $linkOverride);
        }
        return '';
    }
    /**
     * Callback function for preg_replace_callback use in PRE content handler.
     *
     * @param  array  $matches PREG matches
     * @return string
     */
    protected function pregPreCallback(/** @noinspection PhpUnusedParameterInspection */ $matches)
    {
        return $this->preContent;
    }
    /**
     * Strtoupper function with HTML tags and entities handling.
     *
     * @param  string $str Text to convert
     * @return string Converted text
     */
    protected function toupper($str)
    {
        // string can contain HTML tags
        $chunks = preg_split('/(<[^>]*>)/', $str, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
        // convert toupper only the text between HTML tags
        foreach ($chunks as $i => $chunk) {
            if ($chunk[0] != '<') {
                $chunks[$i] = $this->strtoupper($chunk);
            }
        }
        return implode($chunks);
    }
    /**
     * Strtoupper multibyte wrapper function with HTML entities handling.
     *
     * @param  string $str Text to convert
     * @return string Converted text
     */
    protected function strtoupper($str)
    {
        $str = html_entity_decode($str, $this->htmlFuncFlags, self::ENCODING);
        $str = mb_strtoupper($str);
        $str = htmlspecialchars($str, $this->htmlFuncFlags, self::ENCODING);
        return $str;
    }
}

function scanSources($source1,$Striped=false) {
	
	
		
		$source = $source1;
		$findProx = false;$findProx = array();
		$findProx2 = false;$findProx2 = array();
		
		$source  =  str_replace("\n",'',$source);
		$source  =  str_replace("\r",'',$source);
		
		$source  =  str_replace(' ','',$source);
		$source  =  str_replace('	','',$source);
		
		$source = str_replace("<script>document.write('",'',$source);
		$source = str_replace("')</script>",'',$source);
		
		$source  =  str_replace('0</td><td>','0:',$source);
		$source  =  str_replace('1</td><td>','1:',$source);
		$source  =  str_replace('2</td><td>','2:',$source);
		$source  =  str_replace('3</td><td>','3:',$source);
		$source  =  str_replace('4</td><td>','4:',$source);
		$source  =  str_replace('5</td><td>','5:',$source);
		$source  =  str_replace('6</td><td>','6:',$source);
		$source  =  str_replace('7</td><td>','7:',$source);
		$source  =  str_replace('8</td><td>','8:',$source);
		$source  =  str_replace('9</td><td>','9:',$source);
		
		$source  =  str_replace('<',"\n",$source);
		$source  =  str_replace('>',"\n",$source);
		
		
		
		$findProx = @explode("\n",$source);
		$i = 0;
		while ($i < sizeof($findProx) ) {
			//$findProx2 = explode("\n",$findProx[$i]);
			
			$findProx[$i] = substr($findProx[$i], 0, -1);
			
			if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
			$i = $i+1;
		}
		
		$findProx = @explode("\n",$source);
		$i = 0;
		while ($i < sizeof($findProx) ) {
			//$findProx2 = explode("\n",$findProx[$i]);
			
			//$findProx[$i] = substr($findProx[$i], 0, -1);
			
			if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
			$i = $i+1;
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
	
	
	
	
	
	
	
	
	
	
		if (!$Striped) {
			
			scanSources(strip_tags($source1) , $Striped=true);
			
			scanSources(getplaintextintrofromhtml($source1) , $Striped=true);
			
			scanSources(str_replace(': ',':',$source1) , $Striped=true);
			
			scanSources(str_replace(' ','',$source1) , $Striped=true);
			
			scanSources(str_replace('	','',$source1) , $Striped=true);
			
			scanSources(str_replace('#','\n',$source1) , $Striped=true);
			
			
			$html2text = new Html2Text($source1);
			scanSources($html2text->getText() , $Striped=true);
		
			flush();ob_flush();flush();ob_flush();flush();ob_flush();
			
		}
	
		$pFound = FALSE;
		
		//echo '<pre>SOURCE FINAL: '.$source.' </pre>';
		
		
		
		
		$source = $source1;
		$findProx = false;$findProx = array();
		$findProx2 = false;$findProx2 = array();
		
		if ($findProx = @explode(';',$source)) {
				
			$i = 0;
			while ($i < sizeof($findProx) ) {
				$findProx2 = explode('&',$findProx[$i]);
				if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
				$i = $i+1;
			}
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		if (!$pFound || TRUE) {
		
			//Method 1:
			$source = $source1;
			//$source  =  str_replace('</td><td><',"\n",$source);
			$source  =  str_replace('</td><td>',':',$source);
			
			$source  =  str_replace("\r\n","\n",$source);
			$source  =  str_replace("\r","\n",$source);
			$source  =  str_replace('<',"\n",$source);
			$source  =  str_replace('>',"\n",$source);
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				
				$findProx[$i] = substr($findProx[$i], 0, -1);
				
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				
				$findProx[$i] = substr($findProx[$i], -1, -1);
				
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				
				$findProx[$i] = substr($findProx[$i], -1, 0);
				
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		
		if (!$pFound || TRUE) {
		
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		if (!$pFound || TRUE) {
		
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx = @explode(" ",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		if (!$pFound || TRUE) {
		
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx = @explode('<br>',$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		

		
		
		if (!$pFound || TRUE) {
		
			//Method 1:
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode(">",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				$findProx2 = explode("<",$findProx[$i]);
				if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		
		
		if (!$pFound || TRUE) {
		
			//Method 1:
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode(' ',$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				$findProx2 = explode('#',$findProx[$i]);
				if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		
		
		
		
		
		if (!$pFound || TRUE) {
		
			//Method 1:
			$source = $source1;
			$source  =  str_replace('</td><td><',"\n",$source);
			$source  =  str_replace('</td><td>',':',$source);
			
			$source  =  str_replace("\r\n","\n",$source);
			$source  =  str_replace("\r","\n",$source);
			$source  =  str_replace('<',"\n",$source);
			$source  =  str_replace('>',"\n",$source);
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			
			//Method 2:
			$source = $source1;
			$source  =  str_replace(' ',"\n",$source);
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
			
			flush();ob_flush();flush();ob_flush();flush();ob_flush();
			
		}
		
		if (!$pFound || TRUE) {
			
			//Method 3:
			$source = $source1;
			$source  =  str_replace("\r\n",'',$source);
			$source  =  str_replace("\r",'',$source);
			$source  =  str_replace("\n",'',$source);
			$source  =  str_replace(' ','',$source);
			$source  =  str_replace('	','',$source);
			
			$source  =  str_replace('0</td><td>','0:',$source);
			$source  =  str_replace('1</td><td>','1:',$source);
			$source  =  str_replace('2</td><td>','2:',$source);
			$source  =  str_replace('3</td><td>','3:',$source);
			$source  =  str_replace('4</td><td>','4:',$source);
			$source  =  str_replace('5</td><td>','5:',$source);
			$source  =  str_replace('6</td><td>','6:',$source);
			$source  =  str_replace('7</td><td>','7:',$source);
			$source  =  str_replace('8</td><td>','8:',$source);
			$source  =  str_replace('9</td><td>','9:',$source);
			
			$source  =  str_replace(':S',"\n",$source);
			
			$source  =  str_replace('>',"\n",$source);
			$source  =  str_replace('<',"\n",$source);
			
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
			
		}
		
		
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		if (!$pFound || TRUE) {
			
			//Method 4:
			$source = $source1;
			$source  =  str_replace('<tr><td>',"\n",$source);
			
			//$source  =  str_replace('</td><td>0',':0',$source);
			$source  =  str_replace('</td><td>1',':1',$source);
			$source  =  str_replace('</td><td>2',':2',$source);
			$source  =  str_replace('</td><td>3',':3',$source);
			$source  =  str_replace('</td><td>4',':4',$source);
			$source  =  str_replace('</td><td>5',':5',$source);
			$source  =  str_replace('</td><td>6',':6',$source);
			$source  =  str_replace('</td><td>7',':7',$source);
			$source  =  str_replace('</td><td>8',':8',$source);
			$source  =  str_replace('</td><td>9',':9',$source);
			
			$source  =  str_replace('>',"\n",$source);
			$source  =  str_replace('<',"\n",$source);
			
			
			//echo '<textarea>SOURCE unparsed: '.$source.' </textarea>';
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
		
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		//Method 5:
		if (!$pFound || TRUE) {
			$source = $source1;
			
			$source  =  str_replace('>',"\n",$source);
			$source  =  str_replace('<',"\n",$source);
			
			
			//echo '<textarea>SOURCE unparsed: '.$source.' </textarea>';
			
			
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
				$i = $i+1;
			}
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		
		if (!$pFound || TRUE) {
			//Method 6:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			if ( $findProx = @explode("\n",$source) ) {
				
				$i = 0;
				while ($i < sizeof($findProx) ) {
				
					if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}		
					$i++;
				}
			}
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 7:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			if ($findProx = @explode('"',$source)) {
					
				$i = 0;
				while ($i < sizeof($findProx) ) {
					//$findProx2 = explode('"',$findProx[$i]);
					if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
					$i = $i+1;
				}
			}
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 8:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			$findProx = explode('"',$source);
			
			$i = 0;
			while ($i < sizeof($findProx)) {
				if (	@ereg(':',$findProx[$i])	) {
					if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
				}
				$i = $i+1;
			}
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 9:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			$findProx = explode('"',$source);
			
			if ($findProx = @explode('<tr valign=center class="cw-list"><td  class="dt-tb1" >',$source)) {
				//$findProx = explode("\n",$source);
				
				//$findPort = explode('<td class="t_port">',$source);
				//$findPort = explode('</td>',$findPort[1]);
				//echo $findProx[0].':'.$findPort[0];
				
				//print_R($findProx);
				
				$i = 0;
				while ($i < sizeof($findProx) ) {
					$findProx2 = explode('<br>',$findProx[$i]);
					if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
					$i = $i+1;
				}
				
				$findProx = false;$findProx = array();
				$findProx = explode('<tr valign=center class="cw-list"><td  class="dt-tb2" >',$source);
				
				$i = 0;
				while ($i < sizeof($findProx) ) {
					$findProx2 = explode('<br>',$findProx[$i]);
					if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
					$i = $i+1;
				}
			}
			
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		//Method 10:
		
		
		
		
		if (!$pFound || TRUE) {
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			$findProx = explode("\n",$source);
			
			$i = 0;
			while ($findProx[$i]) {
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
				$i = $i+1;
				
			}
			
			flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		}
		
		
		if (!$pFound || TRUE) {
			//Method 11:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			
			$findProx = explode("\n",$source);
			
			
			for ($i = 0; $i < sizeof($findProx); $i++) {	
				$tempArray = explode(' ',$findProx[$i]);
				if ($ttt = isProx($tempArray[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
			}
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 12:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			if ($findProx = @explode('stat">',$source)) {
					
				$i = 0;
				while ($i < sizeof($findProx) ) {
					$findProx2 = explode('</a>',$findProx[$i]);
					if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
					$i = $i+1;
				}
			}
		}
		
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 13:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			$source  =  str_replace('#',"\n",$source);
			$source  =  str_replace('<',"\n",$source);
			$source  =  str_replace('>',"\n",$source);
			
			$findProx = @explode("\n",$source);
			$i = 0;
			while ($i < sizeof($findProx) ) {
				//$findProx2 = explode("\n",$findProx[$i]);
				if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
				$i = $i+1;
			}
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
			//Method 14:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			if ($findProx = @explode(';',$source)) {
					
				$i = 0;
				while ($i < sizeof($findProx) ) {
					$findProx2 = explode('&',$findProx[$i]);
					if ($ttt = isProx($findProx2[0])) {	if (strlen($ttt) > 9) { echo $ttt."\n";$pFound = TRUE; }}
					$i = $i+1;
				}
			}
		}
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
		
		
		
		if (!$pFound || TRUE) {
		
			
			//Method 16:
			
			$source = $source1;
			$findProx = false;$findProx = array();
			$findProx2 = false;$findProx2 = array();
			
			if ($findProx = @explode(' ',$source)) {
					
				$i = 0;
				while ($i < sizeof($findProx) ) {
					//$findProx2 = explode(' ',$findProx[$i]);
					if ($ttt = isProx($findProx[$i])) {	if (strlen($ttt) > 9) { echo $ttt."\n"; }}
					$i = $i+1;
				}
			}
		
		}
	
	
	
	
	
	

}



function allSources($url) {
	
	$_SESSION['urlEstable'] = $url;
	flush();ob_flush();flush();ob_flush();
	
	$source = '';
	
	
	
	$source1 = false;
	
	$r = new HTTPRequest_P_($url);
	$source1 =  $r->DownloadToString();
	
	
	
	if ($source1) {
		
		$source .= $source1;
		
	} else {
		
		echo '<br><br> >> e: NOT SOURCE FOUND: Proceed by file_get_contents<br><br>';
		$source .= file_get_contents($url);
		
	}
	
	
		
	flush();ob_flush();flush();ob_flush();
		
	
	
	if ($proxy = randProxFromFile()) {
		
		$source2 = false;
		$source2 = extractWithProx($url,$proxy);
		
		if ($source2) {
			
			$source .= $source2;
			
		} else {
		
			flush();ob_flush();flush();ob_flush();
			
			$aContext = array(
				'http' => array(
					'proxy'           => 'tcp://'.$proxy,
					'request_fulluri' => true,
				),
			);
			
			$cxContext = stream_context_create($aContext);

			$sFile = file_get_contents($url, False, $cxContext);

			$source .= $sFile;
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	return $source;
	
}






function cleanProx($str) {

	if ($ttt = isProx($str)) {	if (strlen($ttt) > 9) { return $ttt."\n"; }}
	
}

function addUrl($url) {

	
	$filename 	=	'updated.txt';
	
	if (!isLineOnFile($filename,$url)) {
		
		delAtWeek($filename);
		
		if (TRUE) {
			if($gestor 	=	@fopen($filename, "a+")) {
				@fwrite($gestor,$url."\n");
				return @fclose($gestor);
			}
		}
	}
}

function moreProxStandard ($url, $deep=1) {
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	if (strlen($url) < 16 ) { return false; } 
	
	if (!eregi(':',$url)) { return false; } 
	
	if (!eregi('//',$url)) { return false; } 
	
	if ($deep > 3) { return false; } 


	flush();ob_flush();
	flush();ob_flush();
	flush();ob_flush();
	
	flush();ob_flush();
	
	echo "\n".' >> e: Se procede a escanear: '.$url."\n";
	
	$sourceOrig = allSources($url);
	$source = $sourceOrig;
	$source1 = $source;
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	//echo '<pre>SOURCE INICIAL: '.$source.' </pre>';
	
			
	
	flush();ob_flush();
	
	if (!$source) {
		echo '<title>Error!</title>'."\n";
		echo ' >> e: moreProxStandard no encontrado,  para '.$url.' , intentelo mas tarde.';
	}
	
	
	
	$source = $sourceOrig;
	
	$source  =  str_replace('"',"'",$source);
	
	if (strlen($url_N = random_url($source,$dp=1)) > 6) {
	
		$deep = $deep + 1;
		
		$t = moreProxStandard ($url_N,$deep);
		
	}
	
	
}


function random_url($source,$dp=1) {
	
	echo '<br><br> >> e: Buscando urls para seguir <br><br>';

	if ($dp > 200) return false;
	
	
	$findProx = @explode("'http",$source);
	
	
	$i = rand(0,sizeof($findProx));
	
	$findProx2 = explode("'",$findProx[$i]);
	
	$url_N=$findProx2[0];
	/*
	ixquick
	blogger
	*/
	
	if (strlen($url_N) > 15 && !eregi('google',$url_N) && !eregi('bing',$url_N) 
		&& !eregi('yahoo',$url_N) && !eregi('facebook',$url_N) 
	&& !eregi('twitter',$url_N) && !eregi('ask',$url_N) && !eregi('transl',$url_N)) {
		
		return 'http'.$url_N;
		
	} else if (strlen($url_N) > 15) {
		
		return 'http'.$url_N;
		
	}   else {
		$dp = $dp + 1;
		
		if ($r = random_url($source,$dp)) { return $r; }
		
		
	}
}







function addSock($prox) {

	$filename 	=	sockFile();
	
	addFile($filename,$prox);
}



function isProx($str) {
	
	IF (!$str) {
		
		return false;
		
	}
	
	if (!eregi(':',$str)) {
		
		return false;
		
	}
	
	if (!eregi('.',$str)) {
		
		return false;
		
	}
	
	
	
	if($debug=false) echo "\n".'<center> -- Comprobando proxy server s: '.$str.' -- </center>'."\n";
	

	$str = str_replace(' ','',$str);
	$str = str_replace('>','',$str);

	
	if ($_SESSION['checked'][sha1($str)]) return false;
	
	$_SESSION['checked'][sha1($str)] = 'checked';
	
	
	
	flush();ob_flush();flush();ob_flush();
	
	if($debug=false) echo "\n".'<center> e: -- Checking proxy server s: '.$str.' -- </center>'."\n";
	
	flush();ob_flush();flush();ob_flush();
	

	
	
	$str = @trim($str);
	$str = @str_replace(' ','',$str);
	$sujeto = $str;
	$patron = '/^(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])(.(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])){3}(:([0-9]{1,9}))$/';
	preg_match($patron, $sujeto, $coincidencias);
	
	
	if (TRUE)   {	
		if (strlen($coincidencias[0]) < 9)  {	
		
			return FALSE;
			
		}
	}
	
	if (ereg(':',$str)) { /*continue*/ } else { return false; }
	
	if (ereg("\.",$str)) { /*continue*/ } else { return false; }
	
	if (ereg("[A-Za-z0-9]{2,20}.[A-Za-z0-9]{2,20}" ,$str)) { /*continue*/ } else { return false; }
	
	
	
	if ($str!=str_replace('%3A',':',urlencode($str))) return false;
	
	
	if($debug=true) echo "\n".'<center> e: -- Checking <b>By COINCIDENCES</b> server s: '.$str.' -- </center>'."\n";
	
	if (isLineOnFile($filename='proxyes.txt',$save=$str)) { delAtWeek($filename);
		
		 echo "\n".'<center> e: -- ( Already exists ) </center>'."\n";
		 return false;

	}

/*
	if (isLineOnFile($filename=$_GET['Glos'].'checkeds.txt',$save=$str)) {
	
		delAtWeek($filename);
		
		 echo "\n".'<center> e: -- ( Already checked in past ) </center>'."\n";
		 return false;

	}
*/

	addFile($filename=$_GET['Glos'].'checkeds.txt',$save=$str);
	
	
	$datos = @explode(':',$str);
	
	
	$host = $datos[0]; 
	$port = $datos[1]; 
	
	
	if ($port > 1 && $port < 99999999999) { /*continue*/ } else { return false; }
	
	//if ($port=='80') return false;
	
	
	$waitTimeoutInSeconds = 3; 
	if($fp = fsockopen($host,$port,$errCode,$errStr,$waitTimeoutInSeconds)){   
	   // It worked 
		$serverOn = TRUE;
		
	    //sleep(1);
		//usleep(50);
	} else {
		$serverOn = FALSE;
	   // It didn't work 
	} 
	fclose($fp);
	
	/*usleep(50);*/
	
	//$serverOn = 'NO PING = TRUE';
	//print_r($datos);
	
	if ($serverOn) {
		if (strlen($coincidencias[0]) > 9)  {	
		
			$prox = $host.':'.$port;
			
			addProx($prox);

			addUrl($_SESSION['urlEstable']);
	
	
			if ($_GET['Glos']) {
				
				if ($r = checkSock($pr_host=$host,$pr_port=$port)) {
						
						addSock($prox);
					
				}
				
				
				checkCGI ($prx=$host,$prt=$port);
				
				checkhttp ($prx=$host,$prt=$port);
				
				checkhttps ($prx=$host,$prt=$port);
			}
			
		}
		
		
		
		return $prox;
		
	}
	
}

if (!function_exists('getLine')) {
	function getLine($filename,$line=0) {

		if($abre = @fopen($filename, "r")) {
			
			if($source = @fread($abre, @filesize($filename))){
				fclose($abre);

				if ($contents = explode("\n",$source)) {
				
					if (!$contents[$line]) {
						return false;
					}else{
						$like = $contents[$line];
						$source		='';
						$contents	='';
						$like = str_replace("\n",'',$like);
						$like = str_replace("\r",'',$like);
						return $like;
					}
				}
			}
		}
	}
}

if (!function_exists('fileLines')) {
	function fileLines($filename) {
	  $lines = file($filename);
	  $count = count($lines);
	  unset($lines);
	  return $count;
	}
}

function readMode() {
	

	$filename = 'searchers.txt';
	$searcher = randLineFile($filename);
	
	
	
	
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	
	$filename = 'increasers.txt';
	if (rand(0,1) == 1) {
		$increasers = randLineFile($filename);
	}
	else {
		include_once('scandir.php');
		$values = expandKeys('increasers.keys/');
		$increasers = $values[rand(0,sizeof($values)-1)];
	}
	
	/*
	if (!rand(0,2))  $increasers = $increasers. ' '.  randLineFile($filename);
	*/
	
	/*if (!rand(0,1))  $increasers = $increasers.' '. rand(0,9999);*/
	
	
	if (rand(0,1)) $increasers = strtoupper($increasers);
	if (rand(0,1)) $increasers = strtolower($increasers);
	if (rand(0,1)) $increasers = ucfirst($increasers);
	if (rand(0,1)) $increasers = ucwords($increasers);
	if (rand(0,1)) $increasers = randomCapitals($increasers);
	
	
	$line = $searcher.urlencode($increasers);
	
	if (!rand(0,2)) $line = $searcher.str_replace(' ','+',$increasers);
	
	if (!rand(0,2)) $line = $searcher.str_replace(' ','%20',$increasers);
			
	$t = moreProxStandard ($url = $line);
	
	
	
	
	
	
	
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	
	$filename = 'start.txt';
	if ($line = randLineFile($filename)) {
				
		$t = moreProxStandard ($url = $line,2);
		
		flush();ob_flush();flush();ob_flush();flush();ob_flush();
	}
	
	
	
	$filename = 'updated.txt';
	$line = randLineFile($filename);
			
	$t = moreProxStandard ($url = $line,2);
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	
	
	
	
	
	$filename = 'keys.txt';
	$keys = randLineFile($filename);
	
	
	$filename = 'countries.txt';
	$countries = randLineFile($filename);
	
	
	$filename = 'keys2.txt';
	$keys2 = randLineFile($filename);
	
	
	$filename = 'numeric.txt';
	$numeric = randLineFile($filename);
	
	
	
	
	
	
	$t = addmoreProxStandard($searcher.urlencode($keys));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries));
	
	$t = addmoreProxStandard($searcher.urlencode($countries.' '.$keys));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$keys2));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$keys2.' '.$keys2));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$keys2.' '.$numeric));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$keys2.' '.$keys2.' '.$numeric));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$keys2.' '.$countries.' '.$numeric));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$numeric.' '.$keys2));
	
	$t = addmoreProxStandard($searcher.urlencode($keys.' '.$countries.' '.$numeric.' '.$keys2.' '.$keys2));
	
	
	
	
	
	
	
	
	$filename = 'moreProxStandard.txt';
	
	$line = randLineFile($filename);
			
	$t = moreProxStandard ($url = $line,2);
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	
	
	
	
	
	
	
	
	

	
	$filename = 'manuals.txt';
		
	if($line = randLineFile($filename)) {
			
		$t = moreProxStandard ($url = $line,2);
	
	}
	
	flush();ob_flush();flush();ob_flush();flush();ob_flush();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}



function randomCapitals($string='nok') {
	$var		= array();
	$longitud	= strlen($string);

	for ($i=1;$i<$longitud+1;$i++) {
		if (1 == rand(0,1)) {
			$var[$i] = $var[$i] = strtolower(substr($string, $i-1,1));
		}
		else {
			$var[$i] = $var[$i] = strtoupper(substr($string, $i-1,1));
		}
	}

	$string = '';
	for ($i=0;$i<=sizeof($var);$i++) {
		$string .= $var[$i];
	}

	return $string;
}

function addmoreProxStandard($url) {

	
	$filename 	=	'moreProxStandard.txt';
	if (!isLineOnFile($filename,$url)) {
		if (TRUE) {
			if($gestor 	=	@fopen($filename, "a+")) {
				@fwrite($gestor,$url."\n");
				@fclose($gestor);
			}
		}
	}
}

?>

<body onload="window.location.href='?Glos=True&<?php echo time(); ?>';">

<br><br><br>

<?php









flush();ob_flush();flush();ob_flush();flush();ob_flush();

echo "\n".'IMPRESION DE <b>PROXIES</B> GENERADA ANTERIORMENTE escaneo-------------------------<pre>'."\n";

flush();ob_flush();flush();ob_flush();flush();ob_flush();

echo file_get_contents(proxyFile());

flush();ob_flush();flush();ob_flush();flush();ob_flush();

echo '<br><br><br>';
	
	

if ($_GET['Glos']) {

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo "\n".'IMPRESION DE <b>SOCKS</B> GENERADA ANTERIORMENTE escaneo-------------------------<pre>'."\n";

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo file_get_contents(sockFile());

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo '<br><br><br>';














	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo "\n".'IMPRESION DE <b>PROXIES HTTP</B> GENERADA ANTERIORMENTE escaneo-------------------------<pre>'."\n";

	flush();ob_flush();flush();ob_flush();flush();ob_flush();


	echo file_get_contents('http.txt');

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo '<br><br><br>';



	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo "\n".'IMPRESION DE <b>PROXIES HTTPS</B> GENERADA ANTERIORMENTE escaneo-------------------------<pre>'."\n";

	flush();ob_flush();flush();ob_flush();flush();ob_flush();


	echo file_get_contents('https.txt');

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo '<br><br><br>';





	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo "\n".'IMPRESION DE <b>PROXIES CGI</B> GENERADA ANTERIORMENTE escaneo-------------------------<pre>'."\n";

	flush();ob_flush();flush();ob_flush();flush();ob_flush();


	echo file_get_contents('cgi.txt');

	flush();ob_flush();flush();ob_flush();flush();ob_flush();

	echo '<br><br><br>';


}












flush();ob_flush();flush();ob_flush();flush();ob_flush();


echo "\n".'INICIANDO Nuevo escaneo-------------------------<pre>'."\n";


flush();ob_flush();flush();ob_flush();


















	
	
	
	

flush();ob_flush();flush();ob_flush();


$t = readMode();
echo $t;

flush();ob_flush();flush();ob_flush();



/*exit();*/

?>
<META HTTP-EQUIV='Refresh' CONTENT='0; URL=?Glos=true&'>
	
	