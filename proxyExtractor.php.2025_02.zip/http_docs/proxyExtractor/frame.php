<html>
<head><title> Increasers - <?php echo  $_SERVER['HTTP_HOST']; ?></title></head>

<META HTTP-EQUIV="REFRESH" CONTENT="1;URL=?">

<body>
<iframe id=frameP name=frameP 
 src="index.php"
onload="this.src=this.src;"
 onerror="this.src=this.src;"

 style="width:80%;height:80%;"></iframe>
</body>
</html>