﻿<?PHP
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.0
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the pasts

/*$lim = rand(300,999);*/

$lim = 99999;

set_time_limit($lim);

ini_set('max_execution_time', $lim);

ini_set('default_socket_timeout', 3);

//ini_set('memory_limit','50M');

ini_set('display_errors', 0);




function cleanRep($filename) {
	
		if($abre = @fopen($filename, "r")) {
			$source = @fread($abre, @filesize($filename));
			@fclose($abre);
			
			$lineas = explode("\n",$source);
			$linea = array();
			$arrayn = array();
			
			for ($i = 0; $i <= sizeof($lineas); $i++) {
				
				if (!$arrayn[$lineas[$i]]) {
					$final .= $lineas[$i]."\n";
					$arrayn[$lineas[$i]] = true;
				}
			}
		
			$abre = @fopen($filename, "w");
			@fwrite($abre, $final);
			@fclose($abre);
		}
}

function randLineFile($filename,$line=false,$count=0) {
	

	//echo $line;

	if($abre = @fopen($filename, "r")) {
		//echo 'abre';
		/*
		if ($bufer = fgets($abre,$line)) {
			return $bufer;
			@fclose($abre);
		}
		*/
		
		if($source = @fread($abre, @filesize($filename))){
			fclose($abre);

			if ($contents = explode("\n",$source)) {
				
				
				
				if (!$line) {
					
					$line  = rand(0,sizeof($contents)-1);
					
					if (!$contents[$line] && $count <= 3) {
						
						$count++;
						return randLineFile($filename,false,$count);
						
					}
				}
					
			
				if (!$contents[$line]) {
					
					return false;
					
				}
				else {
					$like = $contents[$line];
					//unset $contents;
					$source		='';
					$contents	='';
					
					return str_replace("\n",'',str_replace("\r",'',$like));
					
				}
			}
		}
	}
}




$url = randLineFile('searchers.txt');

if (rand(0,9) == 1) {
	$url .= randLineFile('increasers.txt');
}
else {
	include_once('scandir.php');
	$values = expandKeys('increasers.keys/');
	$url .= $values[rand(0,sizeof($values)-1)];
}

?>
<script>

window.open('<?php echo $url; ?>','gosearch');

</script>
<META HTTP-EQUIV='Refresh' CONTENT='5; URL=?'>
	
	